﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace scrabble
{
    public class Dictionnaire
    {
        string[][] mots_dico;
        int taille_dico;
        string langue_dico;

      /// <summary>
      /// Extrait du fichier les mot du dictionnaire pour les classer dans un tableau de tableau en fonction de leurs longueur 
      /// </summary>
      /// <param name="fichier"></param>
      /// <param name="langue"></param>
        public Dictionnaire(string fichier,string langue)
        {
            string texte = System.IO.File.ReadAllText(fichier);
            string[][] mots_dico = new string[14][];
            string[] nombre = new string[14] { "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16" };
            string[] tab_dico = texte.Split(nombre,StringSplitOptions.None);    // fait un tableau avec dans chaque case les mots de 3/4/5/... lettres séparés par un " "
            for (int i = 0; i < 14; i++)

            {
                mots_dico[i] = tab_dico[i].Split(' ');      // split chaque ligne de tableau lorsqu'il y'a l'espace " " pour faire un tableau de tableau
            }
            this.mots_dico = mots_dico;
            this.langue_dico = langue;


            for(int j=0;j<mots_dico.Length;j++)
            {
                taille_dico += mots_dico[j].Length;
                // FAIRE UN TABLEAU AVC LONGUEUR 
            }
            this.taille_dico = taille_dico;

        }


        /// <summary>
        /// renvoie une description du dico
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return "taille du dico :"+ taille_dico + " langue du dico "+ langue_dico + "nombre de mot de taille 12....etc";
        }


        /// <summary>
        /// trouve la longueur du mot, va dans la ligne du tableau associée et la parcours jusquà trouver le mot. Renvoie faux si le mot n'est pas trouvé
        /// </summary>
        /// <param name="mot"></param>
        /// <returns></returns>
        public bool RechDichoRecursif(string mot)
        {
            bool res = false;
            int longueur = mot.Length;

            for(int i =0;i< mots_dico[longueur-2].Length;i++)
            {
                if (mot.ToUpper() == mots_dico[longueur-2][i])
                    res= true;
            }

            return res;

        }

    }
}
