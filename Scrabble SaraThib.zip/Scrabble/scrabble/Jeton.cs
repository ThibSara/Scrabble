﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace scrabble
{
    public class Jeton
    {
        char lettre;
        int score;
        int nbidentique;

        #region propriétés
        public char Lettre
        {
            get { return lettre; }
        }

        public int Score
        {
            get { return score; }
        }

        public int Nbidentique
        {
            get { return nbidentique; }
        }
        #endregion


        public Jeton(char lettre, int score, int nbidentique)
        {
            this.lettre = lettre;
            this.score = score;
            this.nbidentique = nbidentique;
        }

        /// <summary>
        /// renvoie un description du jeton
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return "lettre: " + lettre + " score: " + score + "nombre de jeton identique: " + nbidentique;
        }



    }
}
