﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace scrabble
{   
    public class Sac_Jetons
    {
        List<Jeton> liste_jeton_sac;

        public List<Jeton> Liste_jeton_sac
        {
            get { return liste_jeton_sac; }
        }


        /// <summary>
        /// extrait de fichier les jetons avec leurs score et leur multiplicité
        /// </summary>
        /// <param name="fichier"></param>
        public Sac_Jetons(String fichier )
        {
            // fichier = @"C:\Users\sarat\Desktop\Scrabble\Jetons.txt"

            string[] lines = System.IO.File.ReadAllLines(fichier);

             List<Jeton> liste_jeton_sac = new List<Jeton>();

            for(int i =0;i<lines.Length; i++)
            {
                string[] tableau = lines[i].Split(';');

             //  Console.Write(Convert.ToChar(tableau[0]) +" "+ Convert.ToInt32(tableau[1])+ " "+ Convert.ToInt32(tableau[2]) +"\n");

                char var1 = Convert.ToChar(tableau[0]);
                int var2 = Convert.ToInt32(tableau[1]);
                int var3 = Convert.ToInt32(tableau[2]);

               Jeton jeton = new Jeton(var1, var2, var3);


                for (int a = 0; a < var3; a++) // ajoute le bon nombre de doublon du jeton 
                {
                    liste_jeton_sac.Add(jeton);
                }
            }
            this.liste_jeton_sac = liste_jeton_sac;
        }



        /// <summary>
        /// affiche le contenu du sac de jetons avec leurs doubolons
        /// </summary>
        /// <returns></returns>     
        public override string ToString()
        {           
            string listeJ = null;
            for (int i = 0; i < liste_jeton_sac.Count; i++)
            {
                listeJ += liste_jeton_sac[i].Lettre +" ";
            }
            return "contenu du sac de jeton : "+listeJ ;     
        }


       
        /// <summary>
        /// retire un jeton "au hasard" ( grâce à un nombre aléatoire r passé en paramètre: initialisé dans le program) du sac de jeton
        /// </summary>
        /// <param name="r"></param>
        /// <returns></returns>     
        public Jeton Retire_Jeton(int r)
        {
            Jeton a = liste_jeton_sac[r];
            liste_jeton_sac.RemoveAt(r);
            return a;
        }


        /// <summary>
        /// permet au joueur de changer sa main courante en remettant ses jetons dans le sac de jetons (pour repiocher ses jetons cette fonction sera realisée dans le main)
        /// </summary>
        /// <param name="player"></param>
        public void changer_jeton(Joueur player)
        {
            for(int i=0;i<player.Liste_jetons_main.Count;i++)
            {
                liste_jeton_sac.Add(player.Liste_jetons_main[i]); 
                player.Liste_jetons_main.Remove(player.Liste_jetons_main[i]); 
            }
        }
    }

}
