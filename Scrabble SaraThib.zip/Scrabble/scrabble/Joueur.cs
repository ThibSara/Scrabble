﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.IO;

namespace scrabble
{


    public class Joueur
    {
        string nom;
        int score;
        List<string> liste_mots;
        List<Jeton> liste_jetons_main;
        int nombre_mots;
        //  int nombre_joueur; 

        #region propriétés
        public string Nom
        {
            get { return this.nom; }
        }
        public int Score
        {
            get { return this.score; }
            set { this.score = value; }
        }
        public List<string> Liste_mots
        {
            get { return liste_mots; }
            set { this.liste_mots = value; }
        }

        public List<Jeton> Liste_jetons_main
        {
            get { return liste_jetons_main; }
        }

        #endregion


        #region constructeur


        /// <summary>
        /// Associe à un joueur son nom, son score de base, sa liste de mots et les jetons de sa main
        /// </summary>
        /// <param name="nom"></param>
        /// <param name="liste_jetons_mains"></param>
        public Joueur(string nom, List<Jeton> liste_jetons_mains)
        {
            this.nom = nom;    
            this.score = 0;          
            this.liste_mots = null;
            this.liste_jetons_main = liste_jetons_mains;
            liste_mots = new List<string>();

            /*
            if (this.nom == null)
            {
                this.nom = "joueur " + nombre_joueur;
            }
            */
            int nombre_mot = 0;

        } 


        #endregion



        #region methodes


        /// <summary>
        /// ajoute le mot écrit à la liste de mot du joueur
        /// </summary>
        /// <param name="mot"></param>

        public void Add_Mot(string mot)
        {
                liste_mots.Add(mot);
        } 


        /// <summary>
        /// renvoie un descriptif de la main du joueur, de ses mots, de son score et de son nom
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            string listeMot = null;
            for(int i =0;i<liste_mots.Count;i++)
            {
                listeMot += liste_mots[i]+" ";
            }

            string listeJeton = null;
            for (int i = 0; i < liste_jetons_main.Count; i++)
            {
                listeJeton += liste_jetons_main[i].Lettre +" ";
            }


            return "joueur: " + nom + "     score: " + score+ "     liste de mot trouvés: " + listeMot + "       liste de jeton: " + listeJeton;
        }


        /// <summary>
        /// ajoute le score de son mot à ses points de score
        /// </summary>
        /// <param name="val"></param>
        public void Add_Score(int val)
        {
            score = score + val;

        }


        /// <summary>
        /// ajoute le jeton monjeton dans la liste de jeton du joueur
        /// </summary>
        /// <param name="monjeton"></param>
        public void Add_Main_Courante(Jeton monjeton)
        {
            liste_jetons_main.Add(monjeton);
        }


        /// <summary>
        /// retire le jeton monjeton de la liste de jeton du joueur
        /// </summary>
        /// <param name="monjeton"></param>
        public void Remove_Main_Courante(Jeton monjeton)
        {
            liste_jetons_main.Remove(monjeton);
        }


        /// <summary>
        /// teste si les jetons du joueur correspondent bien au mot, si tel est le cas renvoie true
        /// </summary>
        /// <param name="mot"></param>
        /// <returns></returns>
        public bool jetons_mots(string mot)
        {
            mot = mot.ToUpper();
            // List<Jeton> jeton_a_retirer = liste_jetons_main;
            bool test = false;

            for (int i = 0; i < mot.Length; i++)  // trouver si les jetons correspondant au mot 
            {
                test = false;
                char a = Convert.ToChar(mot[i]);
                for (int j = 0; j < liste_jetons_main.Count; j++)
                {
                    

                    if (liste_jetons_main[j].Lettre == mot[i])
                    {
                        test = true;
                       // jeton_a_retirer.Remove(liste_jetons_main[j]);
                    }

                }
                if (test == false)
                {
                    return false;
                }

                //la fonction gere les doublons gere les doublons 
            }
            if (test == true)
            {
                // this.liste_jetons_main= jeton_a_retirer;
                return true;
            }
            else return false;


        } 

        #endregion
    }
}

