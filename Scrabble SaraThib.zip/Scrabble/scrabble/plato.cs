﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace scrabble
{
    public class plato
    {

        Jeton[,] plat;
        int[,] plateau_score;


        public plato(string fileboardvisu, string fichier_score, Sac_Jetons sac)
        {

            string[] lines = System.IO.File.ReadAllLines(fileboardvisu);



            Jeton[,] plat = new Jeton[lines.Length, lines.Length];



            for (int i = 0; i < lines.Length; i++)
            {
                string[] a = lines[i].Split(';');


                for (int j = 0; j < lines.Length; j++) 
                {
                    Jeton b = null;
                    for (int k = 0; k < sac.Liste_jeton_sac.Count; k++)
                    {
                        if (sac.Liste_jeton_sac[k].Lettre == Convert.ToChar(a[j]))
                            b = sac.Liste_jeton_sac[k];

                    }
                    if (b == null)
                    {
                        b = new Jeton(' ', 0, 0); // pour le jeton *
                    }
                    plat[i, j] = b;

                }

            }
            this.plat = plat;


            int[,] plateau_score = new int[15, 15];
            string[] file = System.IO.File.ReadAllLines(fichier_score); //fait appel au fichier score, qui, selon la case sur laquelle est posée le jeton, modifie le score (motx2, lettrex3...)

            {
                for (int i = 0; i < file.Length; i++)
                {
                    string[] a = file[i].Split(';');

                    for (int j = 0; j < a.Length; j++)
                    {

                        plateau_score[i, j] = Convert.ToInt32(a[j]);
                    }

                }
            }
            this.plateau_score = plateau_score;


        }

        #region methodes

        /// <summary>
        /// renvoie le visuel du plateau (un string ne peut avoir qu'une seule couleur de fond d'ou la fonction void ToString())
        /// </summary>
        /// <returns></returns> 
        public override string ToString()
        {
            string visu = "\n";
            string boardu = "\n";
            for (int i = 0; i < plat.GetLength(0); i++)
            {
                for (int j = 0; j < plat.GetLength(1); j++)
                {
                    visu += Convert.ToString((plat[i, j].Lettre))+" ";
                    boardu += Convert.ToString(plateau_score[i, j]);


                    switch(plateau_score[i,j])
                    {
                        case 1:
                            Console.BackgroundColor = ConsoleColor.Green;
                            break;

                        case 2:
                            Console.ResetColor();

                            Console.BackgroundColor = ConsoleColor. Cyan;
                            break;

                        case 3:
                            Console.ResetColor();
                            Console.BackgroundColor = ConsoleColor.Blue;
                            break;

                        case 8:
                            Console.ResetColor();
                            Console.BackgroundColor = ConsoleColor.Magenta;
                            break;
                        case 9:
                            Console.ResetColor();

                            Console.BackgroundColor = ConsoleColor.Red;
                            break;


                    }
                }
                visu += "\n";
                boardu += "\n";

            }
            return visu; //+ boardu
        }


        /// <summary>
        /// affiche le visuel du plateau en couleur
        /// </summary>
        public void Tostring()
        {
            Console.ResetColor();
            for (int i = 0; i < plat.GetLength(0); i++)
            {
                for (int j = 0; j < plat.GetLength(1); j++)
                {                   

                    switch (plateau_score[i, j])
                    {
                        case 1:
                            Console.BackgroundColor = ConsoleColor.Green;

                            break;

                        case 2:
                            Console.ResetColor();

                            Console.BackgroundColor = ConsoleColor.Cyan;
                            break;

                        case 3:
                            Console.ResetColor();
                            Console.BackgroundColor = ConsoleColor.Blue;
                            break;

                        case 8:
                            Console.ResetColor();
                            Console.BackgroundColor = ConsoleColor.Magenta;
                            break;
                        case 9:
                            Console.ResetColor();

                            Console.BackgroundColor = ConsoleColor.Red;
                            break;
                    }
                    Console.Write(plat[i,j].Lettre+" ");
                    Console.BackgroundColor = ConsoleColor.Black;
                }
                Console.WriteLine("");
                Console.BackgroundColor = ConsoleColor.Black;
            }
            Console.ResetColor();
            Console.BackgroundColor = ConsoleColor.Black;

        }



        /// <summary>
        /// teste si le mot, la ligne, la colonne, la direction, les jetons du joueurs sont valide et donc si le mot peut etre posé à l'endroit renseigné ou non, renvoie vrai si c'est le cas
        /// </summary>
        /// <param name="mot"></param>
        /// <param name="ligne"></param>
        /// <param name="colonne"></param>
        /// <param name="direction"></param>
        /// <param name="dico"></param>
        /// <param name="player"></param>
        /// <param name="sac"></param>
        /// <returns></returns>
        public bool Test_Plato(string mot, int ligne, int colonne, char direction, Dictionnaire dico, Joueur player, Sac_Jetons sac) // test si position valable/ si mots compatible / jetons compatibles
        {
            bool res = false;

            //TESTER SI position ligne et position colonne COMPRISE ENTRE 0 ET 14

            if (ligne < 15 && ligne >= 0 && colonne < 15 && colonne >= 0)
                if (direction == 'c' || direction=='l')

            {
                    if (mot.Length < 15 && mot.Length >= 2) // teste si longueur du mot correcte
                    {
                        if (dico.RechDichoRecursif(mot) == true) // teste si mot C dans dictionnaire
                        {
                            // teste si position valable sur la ligne

                            if (direction == 'l')
                            {
                                if (colonne + mot.Length < 15)
                                {
                                    // teste si y'a pas déjà un autre mot sur cette ligne                              

                                    bool a = true;
                                    for (int i = colonne; i < colonne + mot.Length; i++)
                                    {
                                        if (plat[ligne, i].Lettre == ' ' && a == true) // A FAIRE OR plat[ligne, i].Lettre == mot[i-colonne]
                                            a = true;
                                        else
                                            a = false;
                                    }


                                    // A FAIRE TESTER SI MOT COMPATIBLE AVC LES AUTRES 
                                    if (a == true)
                                    {
                                        if (player.jetons_mots(mot) == true)
                                        {
                                            res = true;
                                        }
                                    }

                                }
                            }

                            // teste si position valable sur la colonne
                            else if (direction == 'c')
                            {

                                if (ligne + mot.Length < 15)
                                {
                                    // teste si y'a pas déjà un autre mot sur cette colonne                             

                                    bool a = true;
                                    for (int i = ligne; i < ligne + mot.Length; i++)
                                    {
                                        if (plat[i, colonne].Lettre == ' ' && a == true)
                                            a = true;
                                        else
                                            a = false;
                                    }

                                    // A FAIRE TESTER SI MOT COMPATIBLE AVC LES AUTRES 
                                    if (a == true)
                                    {
                                        if (player.jetons_mots(mot) == true)
                                        {
                                            res = true;
                                        }
                                    }

                                }
                            }
                        }
                    }

                }



            if (res == true)
            {
                add_jeton_plat(mot, ligne, colonne, direction, player);
                player.Add_Mot(mot);
                score(mot, ligne, colonne, direction, sac, player);
            }

            return res;
        }




        /// <summary>
        /// fonction appelee par test_plato si il est vérifié (bool = true) ajoute les jetons du mot au plateau et les retire de la main du joueur
        /// </summary>
        /// <param name="mot"></param>
        /// <param name="ligne"></param>
        /// <param name="colonne"></param>
        /// <param name="direction"></param>
        /// <param name="player"></param>
        public void add_jeton_plat(string mot, int ligne, int colonne, char direction, Joueur player) 
        {
            if (direction == 'l')
            {

                for (int i = colonne; i < colonne + mot.Length; i++)
                {
                    Jeton b = null;
                    for (int k = 0; k < player.Liste_jetons_main.Count; k++)
                    {

                        if (player.Liste_jetons_main[k].Lettre == Convert.ToChar(mot[i - colonne]))
                        {
                            b = player.Liste_jetons_main[k];
                            player.Liste_jetons_main.Remove(b);
                        }


                        plat[ligne, i] = b;
                    }
                }
            }


            else if (direction == 'c')
            {
                for (int i = ligne; i < ligne + mot.Length; i++)
                {
                    Jeton b = null;
                    for (int k = 0; k < player.Liste_jetons_main.Count; k++)
                    {

                        if (player.Liste_jetons_main[k].Lettre == Convert.ToChar(mot[i - ligne]))
                        {
                            b = player.Liste_jetons_main[k];
                            player.Liste_jetons_main.Remove(b);
                        }

                        plat[i, colonne] = b;

                    }

                }

            }

        }

    

        /// <summary>
        /// compte le score du mot rentré en parametre en fonction du score des jetons et du tableau plateau_score
        /// </summary>
        /// <param name="mot"></param>
        /// <param name="ligne"></param>
        /// <param name="colonne"></param>
        /// <param name="direction"></param>
        /// <param name="sac"></param>
        /// <returns></returns>
        public int score(string mot, int ligne, int colonne, char direction, Sac_Jetons sac, Joueur player)
        {
            int score = 0;
            bool motx2 = false;
            bool motx3 = false;

            if (direction == 'l')
            {

                for(int i =colonne;i<colonne+mot.Length;i++)
                {

                    Jeton j = null;  // ON CHERCHE A QUEL JETON CORRESPOND CHAQUE CHAR DU MOT
                    for(int k=0;k<sac.Liste_jeton_sac.Count;k++)
                    {
                        if (sac.Liste_jeton_sac[k].Lettre == Convert.ToChar(mot[i-colonne]))
                            j = sac.Liste_jeton_sac[k];
                    }
                   //  Console.WriteLine(score +" "+ j.Score+ '\n');

                    switch (plateau_score[ligne,i])
                    {
                        case 1:
                            score += j.Score;
                            break;

                        case 2:
                            score += j.Score * 2;
                            break;

                        case 3:
                            score += j.Score * 3;
                            break;

                        case 8:
                            score += j.Score;
                            motx2 = true;
                            break;
                        case 9:
                            score += j.Score;
                            motx3 = true;
                            break;                      
                    }
                }

                if (motx2 == true && motx3== false) score = score * 2;

                if (motx3 == true) score = score * 3;

            }

            if (direction == 'c')
            {


                for (int i = ligne; i < ligne + mot.Length; i++)
                {

                    Jeton j = null;  // ON CHERCHE A QUEL JETON CORRESPOND CHAQUE CHAR DU MOT
                    for (int k = 0; k < sac.Liste_jeton_sac.Count; k++)
                    {
                        if (sac.Liste_jeton_sac[k].Lettre == Convert.ToChar(mot[i-ligne]))
                            j = sac.Liste_jeton_sac[k];

                    }
                    switch (plateau_score[i,colonne])
                    {
                        case 1:
                            score += j.Score;
                            break;

                        case 2:
                            score += j.Score * 2;
                            break;

                        case 3:
                            score += j.Score * 3;
                            break;

                        case 8:
                            score += j.Score;
                            motx2 = true;
                            break;
                        case 9:
                            score += j.Score;
                            motx3 = true;
                            break;
                    }
                    if (motx2 == true && motx3 == false) score = score * 2;

                    if (motx3 == true) score = score * 3;
                }
            }
            player.Add_Score(score);
            return score;
        }

        #endregion
    }
}
          

    

