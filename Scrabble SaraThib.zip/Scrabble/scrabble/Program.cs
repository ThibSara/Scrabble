﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace scrabble
{
    class Program
    {
        Dictionnaire mondico;
        plato monplateau;
        Sac_Jetons monsac_jetons;


        /// <summary>
        /// déroulé du jeu : INITIALISATION: déroulé du menu/ initialisation de la liste de joueurs   
        /// JEU : la partie continue tant que le sac de jeton est rempli/ chaque joueur joue a tour de role / au tour 1 il ne peut pas indiquer la ligne ou la colonne car le jeu commence au milieu
        /// la fonction changer de jeton permet au joueur de passer son tour et de changer de jeton pour le prochain
        /// lorsque le jeton * est detecté dans la main du joueur il est remplacé par le jeton (char indiqué par le joueur, 0,0)
        /// le mot est redemandé tant qu'il n'est pas valable
        /// lorsque le mot est posé le joueur, il pioche le nombre de jeton qui lui manque
        /// le tour passe au joueur suivant
        /// </summary>
        /// <param name="args"></param>
        public static void Main(string[] args)
        {

            // ______________________________________________________________________________________________________________________________________________________________
            // INITIALISATION DU JEU
            // initialisation des fichiers 



            Dictionnaire mondico = new Dictionnaire(@"dictionnaire.txt", "francais");
            Sac_Jetons monsac_jetons = new Sac_Jetons(@"Jetons.txt");
            plato monplateau = new plato(@"instancePlateauvide.txt", @"plateaucase.txt", monsac_jetons);
            List<Joueur> liste_joueur = new List<Joueur>();
            Random r = new Random();



            // déroulé du menu 

            Console.BackgroundColor = ConsoleColor.Red;
            Console.WriteLine("Bonjour et bienvenue sur le SCRABBLE game ! \n entrez le nombre de joueur : ");
            Console.BackgroundColor = ConsoleColor.Black;
            int nb_joueur = Convert.ToInt32(Console.ReadLine());

           while(nb_joueur<2 || nb_joueur>4)
           {
               Console.WriteLine("le nombre de jouer doit etre compris entre 2 et 4 ! \n entrez le nombre de joueur : ");
               nb_joueur = Convert.ToInt32(Console.ReadLine());
           }

           // initialisation des joueurs ( nom, liste<jeton>)
           string nom_des_joueurs = "";
           for(int i=0;i<nb_joueur;i++)
           {
               Console.WriteLine("nom du joueur");
               string nom = Convert.ToString(Console.ReadLine());

               List<Jeton> jeton_joueur = new List<Jeton>();

               for (int j =0;j<7;j++) // remplir la main des joueurs avec 7 jetons tirer avec le r random du sac de jeton
               {
                   int rand = r.Next(1, monsac_jetons.Liste_jeton_sac.Count);
                  Jeton token = monsac_jetons.Retire_Jeton(rand);
                   jeton_joueur.Add(token);
               }

            Joueur player = new Joueur(nom,jeton_joueur);
            liste_joueur.Add(player);
            nom_des_joueurs += nom + " ";
           }

           Console.WriteLine("Les joueurs :" + nom_des_joueurs + "ont rejoint le game");

           // TIMER A RAJOUTER

           Console.WriteLine("_______________________________________________________________________________________________________");




            // ______________________________________________________________________________________________________________________________________________________________
            // JEU 

            int nb_tour = 0; 
           while (monsac_jetons.Liste_jeton_sac.Count!=0) // la partie continue tant que le sac de jeton n'est pas vide
           {
               for(int i =0; i<liste_joueur.Count;i++) // fais defiler chacun des joueurs 
               {
                    Console.Clear();
                    Console.WriteLine("c'est au tour de : "+ liste_joueur[i].ToString());
                   monplateau.Tostring();



                    if (nb_tour == 0) // cas particulier du tour 0 ou le joueur n'indique pas la ligne ni la colonne
                    {
                        Console.WriteLine("pour passer tour et changer de jeton ecrire : changer jeton");
                        Console.WriteLine("indiquez le mot:");
                        string mot = Convert.ToString(Console.ReadLine()).ToUpper();

                        if (mot == "CHANGER JETON") // permet de changer de jeton
                        {
                            monsac_jetons.changer_jeton(liste_joueur[i]);
                            nb_tour--;
                        }
                        else
                        {
                            Console.WriteLine("indiquez la direction ( l ou c ):");
                            char direction = Convert.ToChar(Console.ReadLine());


                            bool test = monplateau.Test_Plato(mot, 7, 7, direction, mondico, liste_joueur[i], monsac_jetons);
                            while (test == false)
                            {
                                Console.WriteLine("IMPOSSIBLE veuillez réessayer");
                                Console.WriteLine("indiquez le mot:");
                                mot = Convert.ToString(Console.ReadLine()).ToUpper();
                                Console.Write("indiquez la direction ( l ou c ):");
                                direction = Convert.ToChar(Console.ReadLine());
                                test = monplateau.Test_Plato(mot, 7, 7, direction, mondico, liste_joueur[i], monsac_jetons);

                            }
                        }


                    }
                    else
                    {
                        // gere le jeton joker *

                        for (int k= 0; k < liste_joueur[i].Liste_jetons_main.Count; k++)
                        {
                            if (liste_joueur[i].Liste_jetons_main[k].Lettre == '*')
                            {
                                Console.WriteLine("quelle lettre voulez vous donner à ce jeton ? ");
                                char letter = Convert.ToChar(Console.ReadLine());
                                Jeton var = new Jeton(letter, 0, 0);
                                liste_joueur[i].Liste_jetons_main[k] = var;
                                Console.WriteLine(liste_joueur[i].ToString());
                            }
                        }





                        Console.WriteLine("pour passer tour et changer de jeton ecrire : changer jeton");
                        Console.WriteLine("indiquez le mot:");
                        string mot = Convert.ToString(Console.ReadLine()).ToUpper();
                        if (mot == "CHANGER JETON")
                        {
                            if(nb_tour == 0) // permet de rester au tour 0 si le joueur choisis de le passer
                            {
                                nb_tour--;
                            }

                            monsac_jetons.changer_jeton(liste_joueur[i]);
                        }
                        else
                        {
                            Console.Write("indiquez la ligne:");
                            int ligne = Convert.ToInt32(Console.ReadLine());
                            Console.Write("indiquez la colonne:");
                            int colonne = Convert.ToInt32(Console.ReadLine());
                            Console.Write("indiquez la direction ( l ou c ):");
                            char direction = Convert.ToChar(Console.ReadLine());


                            //monplateau.Test_Plato(mot, ligne, colonne, direction, mondico, liste_joueur[i], monsac_jetons);


                            bool test = monplateau.Test_Plato(mot, ligne, colonne, direction, mondico, liste_joueur[i], monsac_jetons);
                            while (test == false)
                            {
                                Console.Write("IMPOSSIBLE veuillez réessayer");
                                Console.WriteLine("pour passer tour et changer de jeton ecrire : changer jeton");
                                Console.WriteLine("indiquez le mot:");
                                mot = Convert.ToString(Console.ReadLine()).ToUpper();
                                Console.Write("indiquez la ligne:");
                                ligne = Convert.ToInt32(Console.ReadLine());
                                Console.Write("indiquez la colonne:");
                                colonne = Convert.ToInt32(Console.ReadLine());
                                Console.Write("indiquez la direction ( l ou c ):");
                                direction = Convert.ToChar(Console.ReadLine());
                                test = monplateau.Test_Plato(mot, ligne, colonne, direction, mondico, liste_joueur[i], monsac_jetons);

                            }
                        }
                    }
                   monplateau.Tostring();


                    // repiocher des jetons
                    int nb_jeton = liste_joueur[i].Liste_jetons_main.Count;
                    string nouveaux_jetons = "";
                    for (int k = 0; k < 7 - nb_jeton; k++)
                    {
                        if (monsac_jetons.Liste_jeton_sac.Count != 0)
                        {
                            int rand = r.Next(0, monsac_jetons.Liste_jeton_sac.Count + 1);
                            Jeton token = monsac_jetons.Retire_Jeton(rand);
                            liste_joueur[i].Liste_jetons_main.Add(token);
                            nouveaux_jetons += token.Lettre + " ";
                        }
                    }

                    Console.WriteLine("Le joueur: " + liste_joueur[i].Nom + " a pioché les jetons:" + nouveaux_jetons+ " et a gagné "+ liste_joueur[i].Score + " points");
                    Console.WriteLine("_______________________________________________________________________________________________________");


                    nb_tour++;
                }
               
           }



            // FIN DE LA PARTIE
            // ______________________________________________________________________________________________________________________________________________________________
            Console.WriteLine("_______________________________________________________________________________________________________");
            Console.WriteLine("FIN DE LA PARTIE");
            string score = "";
            for (int i = 0; i < liste_joueur.Count; i++)
            {
                score += liste_joueur[i].Nom +" :  " + liste_joueur[i].Score + "points  ";
            }
            Console.WriteLine("SCORE FINAL "+ score);

        }


        /// <summary>
        /// detecte si le jeton joker * est dans la main du joueur et renvoie vrai si c'est le cas 
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public bool jeton_joker(Joueur player)  
        {
            for(int i =0;i<player.Liste_jetons_main.Count;i++)
            {
                if (player.Liste_jetons_main[i].Lettre == '*')
                    return true;
            }
            return false;
        }


        
        

    }
}
