using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using scrabble;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace test_dico
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TrueDictionnaire() // le mot appartient au dictionnaire
        {
            string mot = "lapin";

            var dico = new Dictionnaire(@"dictionnaire.txt", "francais");
            bool res1 = dico.RechDichoRecursif(mot);

            Assert.AreEqual(true, res1);

        }

        [TestMethod]
        public void FalseDictionnaire() // le mot n'appartient pas au dictionnaire
        {
            string mot = "lnvdf";

            var dico = new Dictionnaire(@"dictionnaire.txt", "francais");
            bool res2 = dico.RechDichoRecursif(mot);

            Assert.AreEqual(false, res2);

        }


        [TestMethod]
        public void FalseColonne() // le mot n'entre pas sur le plateau si on le place en colonne

        {
            string mot = "lapin";
            var dico = new Dictionnaire(@"dictionnaire.txt", "francais");
            Sac_Jetons monsac_jetons = new Sac_Jetons(@"Jetons.txt");
            var plateau = new plato(@"instancePlateauvide.txt", @"plateaucase.txt", monsac_jetons);
            List<Jeton> jeton_joueur = new List<Jeton>();


            jeton_joueur.Add(new Jeton('L', 2, 1));
            jeton_joueur.Add(new Jeton('A', 2, 1));
            jeton_joueur.Add(new Jeton('P', 2, 1));
            jeton_joueur.Add(new Jeton('I', 2, 1));
            jeton_joueur.Add(new Jeton('N', 2, 1));
            jeton_joueur.Add(new Jeton('B', 2, 1));
            jeton_joueur.Add(new Jeton('L', 2, 1));



            var joueur = new Joueur("joueur1", jeton_joueur);



            bool res = plateau.Test_Plato(mot, 12, 9, 'c', dico, joueur, monsac_jetons);
            Assert.AreEqual(false, res);

        }

        [TestMethod]

        public void TrueColonne() // le mot entre sur le plateau si on le place en colonne

        {
            var dico = new Dictionnaire(@"dictionnaire.txt", "francais");
            Sac_Jetons monsac_jetons = new Sac_Jetons(@"Jetons.txt");
            var plateau = new plato(@"instancePlateauvide.txt", @"plateaucase.txt", monsac_jetons);
            List<Jeton> jeton_joueur = new List<Jeton>();


            jeton_joueur.Add(new Jeton('L', 2, 1));
            jeton_joueur.Add(new Jeton('A', 2, 1));
            jeton_joueur.Add(new Jeton('P', 2, 1));
            jeton_joueur.Add(new Jeton('I', 2, 1));
            jeton_joueur.Add(new Jeton('N', 2, 1));
            jeton_joueur.Add(new Jeton('B', 2, 1));
            jeton_joueur.Add(new Jeton('L', 2, 1));



            var joueur = new Joueur("joueur1", jeton_joueur);
            Console.WriteLine(joueur.ToString());


            bool res = plateau.Test_Plato("LAPIN", 1, 1, 'c', dico, joueur, monsac_jetons);

            Assert.AreEqual(true, res);

        }

        [TestMethod]
        public void TrueLettres() // les lettres utilisées par le joueur pour faire son mot sont dans sa main courante
        {
            string mot = "LAPIN";


            List<Jeton> jeton_joueur = new List<Jeton>();
            Sac_Jetons monsac_jetons = new Sac_Jetons(@"Jetons.txt");


            jeton_joueur.Add(new Jeton('L', 2, 1));
            jeton_joueur.Add(new Jeton('A', 2, 1));
            jeton_joueur.Add(new Jeton('P', 2, 1));
            jeton_joueur.Add(new Jeton('I', 2, 1));
            jeton_joueur.Add(new Jeton('N', 2, 1));
            jeton_joueur.Add(new Jeton('B', 2, 1));
            jeton_joueur.Add(new Jeton('L', 2, 1));

            Joueur joueur = new Joueur("joueur1", jeton_joueur);


            bool res3 = joueur.jetons_mots(mot);

            Assert.AreEqual(true, res3);

        }

        [TestMethod]
        public void FalseLettres() // les lettres utilisées par le joueur pour faire son mot ne sont pas dans sa main courante
        {
            string mot = "TABLE";


            List<Jeton> jeton_joueur = new List<Jeton>();
            Sac_Jetons monsac_jetons = new Sac_Jetons(@"Jetons.txt");


            jeton_joueur.Add(new Jeton('L', 2, 1));
            jeton_joueur.Add(new Jeton('A', 2, 1));
            jeton_joueur.Add(new Jeton('P', 2, 1));
            jeton_joueur.Add(new Jeton('I', 2, 1));
            jeton_joueur.Add(new Jeton('N', 2, 1));
            jeton_joueur.Add(new Jeton('B', 2, 1));
            jeton_joueur.Add(new Jeton('L', 2, 1));

            var joueur = new Joueur("joueur1", jeton_joueur);

            bool res4 = joueur.jetons_mots(mot);

            Assert.AreEqual(false, res4);

        }



    }
}


